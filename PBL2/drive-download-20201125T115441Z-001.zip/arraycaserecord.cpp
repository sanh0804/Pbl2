#include "arraycaserecord.h"

arrayCaseRecord::arrayCaseRecord()
{

}
